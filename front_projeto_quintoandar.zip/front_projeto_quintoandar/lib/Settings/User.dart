class User {
  String id;
  String email;
  String senha;
  String celular;
  String cpf;
  String dataNasc;
  String nome;
  User(this.id, this.email, this.senha, this.celular, this.cpf, this.dataNasc, this.nome);
}