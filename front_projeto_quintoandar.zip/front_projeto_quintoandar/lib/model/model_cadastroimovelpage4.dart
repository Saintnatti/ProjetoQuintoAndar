import '/flutter_flow/form_field_controller.dart';
import 'package:flutter/material.dart';

import 'flutter_flow_model.dart';

class modelpage4 extends FlutterFlowModel {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Switch widget.
  bool? switchValue1;
  // State field(s) for CheckboxGroup widget.
  List<String>? checkboxGroupValues;
  FormFieldController<List<String>>? checkboxGroupValueController;
  // State field(s) for Switch widget.
  bool? switchValue2;
  // State field(s) for Slider widget.
  double? sliderValue1;
  // State field(s) for Switch widget.
  bool? switchValue3;
  // State field(s) for Slider widget.
  double? sliderValue2;
  // State field(s) for Switch widget.
  bool? switchValue4;
  // State field(s) for Slider widget.
  double? sliderValue3;
  // State field(s) for Switch widget.
  bool? switchValue5;

  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {}

/// Additional helper methods are added here.

}
