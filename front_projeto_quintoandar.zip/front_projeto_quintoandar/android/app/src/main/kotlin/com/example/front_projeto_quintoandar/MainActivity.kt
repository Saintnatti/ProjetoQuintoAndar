package com.example.front_projeto_quintoandar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
